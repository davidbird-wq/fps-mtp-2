import { join } from "node:path";
import { hostname } from "node:os";
import { createServer } from "node:http";
import express from "express";
import cookieParser from "cookie-parser";
import wisp from "wisp-server-node";

import { uvPath } from "@titaniumnetwork-dev/ultraviolet";
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";

// ===== PASSWORD CONFIG =====
const PASSWORD = "Oauth2-forget-it";
// ===========================

const app = express();
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

// Auth middleware
function requireAuth(req, res, next) {
  if (req.cookies && req.cookies.auth === "true") {
    return next();
  }
  if (req.path === "/login" || req.path === "/login/") {
    return next();
  }
  // Allow static assets needed for login page? For simplicity, redirect everything
  return res.redirect("/login");
}

// Login page
app.get("/login", (req, res) => {
  if (req.cookies && req.cookies.auth === "true") {
    return res.redirect("/");
  }

  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - Ultraviolet Proxy</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      padding: 20px;
    }
    .container {
      background: rgba(255, 255, 255, 0.06);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      padding: 40px 36px;
      width: 100%;
      max-width: 400px;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.4);
      text-align: center;
    }
    h1 { font-size: 1.6rem; margin-bottom: 8px; font-weight: 700; }
    .subtitle { color: #a0aec0; font-size: 0.9rem; margin-bottom: 28px; }
    input {
      width: 100%;
      padding: 15px 16px;
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      background: rgba(0, 0, 0, 0.25);
      color: #fff;
      font-size: 1rem;
      outline: none;
      margin-bottom: 14px;
    }
    input:focus { border-color: #7c3aed; }
    button {
      width: 100%;
      padding: 15px;
      border: none;
      border-radius: 12px;
      background: linear-gradient(90deg, #7c3aed, #a855f7);
      color: white;
      font-size: 1.05rem;
      font-weight: 600;
      cursor: pointer;
    }
    button:hover { opacity: 0.95; }
    .error {
      background: rgba(239, 68, 68, 0.2);
      border: 1px solid rgba(239, 68, 68, 0.4);
      color: #fca5a5;
      padding: 12px;
      border-radius: 10px;
      margin-bottom: 16px;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🔒 Ultraviolet Proxy</h1>
    <p class="subtitle">Enter the password to continue</p>
    ${req.query.error ? '<div class="error">Incorrect password</div>' : ''}
    <form method="POST" action="/login">
      <input type="password" name="password" placeholder="Password" required autofocus />
      <button type="submit">Unlock</button>
    </form>
  </div>
</body>
</html>`);
});

// Handle login
app.post("/login", (req, res) => {
  const password = req.body.password || "";
  if (password === PASSWORD) {
    res.cookie("auth", "true", {
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      httpOnly: true,
      sameSite: "lax"
    });
    return res.redirect("/");
  }
  return res.redirect("/login?error=1");
});

// Logout
app.get("/logout", (req, res) => {
  res.clearCookie("auth");
  res.redirect("/login");
});

// Protect everything after this
app.use(requireAuth);

// Load our publicPath first and prioritize it over UV.
app.use(express.static("./public"));
// Load vendor files last.
app.use("/uv/", express.static(uvPath));
app.use("/epoxy/", express.static(epoxyPath));
app.use("/baremux/", express.static(baremuxPath));

// Error for everything else
app.use((req, res) => {
  res.status(404);
  res.sendFile("./public/404.html");
});

const server = createServer();

server.on("request", (req, res) => {
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
  app(req, res);
});

server.on("upgrade", (req, socket, head) => {
  if (req.url.endsWith("/wisp/")) {
    wisp.routeRequest(req, socket, head);
    return;
  }
  socket.end();
});

let port = parseInt(process.env.PORT || "");

if (isNaN(port)) port = 8080;

server.on("listening", () => {
  const address = server.address();
  console.log("Ultraviolet Proxy running!");
  console.log("Password: Oauth2-forget-it");
  console.log(`http://localhost:${address.port}`);
});

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

function shutdown() {
  console.log("SIGTERM signal received: closing HTTP server");
  server.close();
  process.exit(0);
}

server.listen({
  port,
});
