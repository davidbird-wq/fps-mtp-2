# Ultraviolet Proxy (Password Protected)

This is the official Ultraviolet-App with password protection added.

**Password:** `Oauth2-forget-it`

## How to run

```bash
cd ultraviolet-proxy
npm install   # or pnpm install
npm start
```

Then open http://localhost:8080

You will be asked for the password first.

## Features

- Advanced service-worker based proxy (much better site compatibility than basic node-unblocker)
- Supports more modern websites
- Password protected (cookie lasts 7 days)
- Logout available at /logout

## Notes

- Ultraviolet is more powerful than the simple unblocker
- Some very complex sites may still have issues
- Requires a proper domain with HTTPS for best results in Firefox (Chrome works fine on localhost)

